PDMap - Thin sheet permanent deformation map with faults (Haines and Sutherland)

Codes to accompany the paper by Haines and Sutherland (2018), Journal of Geophysical Research: Solid Earth
Contact Rupert Sutherland, Victoria University of Wellington.

The fortran codes are currently manually compiled then run from a linux script. Gmsh is used to create a mesh.
 
NOTE: THIS IS A BETA-TEST VERSION OF THE CODES. IT IS A SUPPLEMENT FOR THE PUBLICATION AND IS NOT SUPPORTED.
A python interface/rewrite, tools to streamline workflow, and documentation are currently under development.

INSTALLATION (linux)

FIRST INSTALL gmsh
http://gmsh.info/

AND you will need a fortran compiler, and python 3.x

SECOND:
Create a directory for pdmap_01
Unzip all files into the directory
Compile each fortran code in the 'code' directory
or run: 'python pdmSetup.py' to compile each fortran source

Look at the test01 subdirectory (first example from paper) to see how codes are implemented by script pdm.sh
