#!/usr/bin/env python
__author__ = "Rupert Sutherland"

""" 
    Compile Permanent Deformation Map programs
	Assumes they exist in subdirectory ./code and 
	compiled programs will go into subdirectory ./bin
	
	To run 
	python pdmSetup.py
"""

import os
import glob

programList = glob.glob("./code/*.f")

for progPath in programList:
    fortranName = progPath.split('/')[-1]
    progName = fortranName.split('.')[0]
    print progPath,fortranName,progName
    os.system('f77 '+progPath+' -o ./bin/'+progName)

