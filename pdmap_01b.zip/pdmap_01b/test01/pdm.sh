#!/usr/bin/env bash
# Rupert Sutherland
# Permanent Deformation Map implementation

# Separately create strain_rate_capacities.dat and stress_potentials.dat

# Bring in fault and boundary data 
# dos2unix JH_input_A_v16_26Mar2014.dat
cp JH_input_A_v16_26Mar2014.dat raw_input_when_using_gmsh.dat


# Define directory where executable files exist
bin="../bin"	

# Expects to have available input: raw_input_when_using_gmsh.dat
# Reformat input to create geometry
$bin/pre_gmsh

echo 'Format geometry for gmsh'
python $bin/gmsh_geometry_for_setup.py

# Open gmsh
# echo "Open gmsh - select file 'gmsh_geometry_for_setup.geo' - Mesh (menu) - 2D (button) - Save (button)"

echo Mesh automatically
# Specify meshing algorithm (1=MeshAdapt, 2=Automatic, 5=Delaunay, 6=Frontal, 7=bamg, 8=delquad)
echo 'Mesh.Algorithm = 1 ;' >> gmsh_geometry_for_setup.geo
# Define 2D geometry
$bin/gmsh gmsh_geometry_for_setup.geo -2 
# Define 2D geometry and maximum element dimension length (in degrees)
# $bin/gmsh gmsh_geometry_for_setup.geo -2 -clmax 0.2

echo Format gmsh output and complete medium with strain_rate_capacities.dat and stress_potentials.dat
# stress and strain values must be on a regular grid 
# must have points within mesh area - interpolated as appropriate - and must have points outside boundary
$bin/post_gmsh

echo 'Hit <Enter> key to continue' ; set junk = ($<)

echo 'General entry point - checks format of input file and completeness of info'
$bin/setup

echo 'Hit <Enter> key to continue' ; set junk = ($<)

echo 'Inversion to minimize sum of squared residuals'
$bin/invert

echo 'Hit <Enter> key to continue' ; set junk = ($<)

echo 'Create *.log text files of output for later plotting'
$bin/output

# To iterate and optimize a solution, run an adjustment code, e.g. adjust_K_uniformly_using_segments_obsonly
# This creates new_setup_input.dat 
# Rename this to be setup_input.dat and iterate: setup-invert-output-adjust

